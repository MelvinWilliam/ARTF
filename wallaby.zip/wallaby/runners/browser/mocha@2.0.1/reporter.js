/*
 * Wallaby.js - v1.0.444
 * http://wallabyjs.com
 * Copyright (c) 2014-2017 Wallaby.js - All Rights Reserved.
 *
 * This source code file is a part of Wallaby.js and is a proprietary (closed source) software.

 * IMPORTANT:
 * Wallaby.js is a tool made by software developers for software developers with passion and love for what we do.
 * Pirating the tool is not only illegal and just morally wrong,
 * it is also unfair to other fellow programmers who are using it legally,
 * and very harmful for the tool and its future.
 */
!function(e){var t,n=e.$_$tracer,i=n.initialSpecId(),s=[];mocha.setup({ui:"bdd",fullTrace:!0,slow:e.wallaby.slowTestThreshold,reporter:function(e){if(e.grepTotal=function(){return!0},e.runTest=function(e){var t=this.test,i=this;this.asyncOnly&&(t.asyncOnly=!0);try{t.on("error",function(e){i.fail(t,e)}),n.specSyncStart();try{t.run(e)}finally{n.specSyncEnd()}}catch(s){e(s)}},e._grep={test:function(e){if(!n.hasSpecFilter())return!0;var t=s.slice(1);return t.push(e.substr(t.join(" ").length+1)),n.specFilter(t)}},n.needToNotifySingleTestRun()){var r=e.hook;e.hook=function(t,i){if("afterEach"!==t)return Function.prototype.apply.call(r,this,arguments);var s=arguments,a=this;n.notifySingleTestAfterEach(function(){Function.prototype.apply.call(r,a,s)}),e.hook=r}}e.on("start",function(){n.started({total:e.total})}),e.on("end",function(){n.complete()}),e.on("suite",function(e){s.push(e.title),t=e}),e.on("suite end",function(){s.pop()}),e.on("test",function(e){e._id=++i,e._failures=[],e._time=(new n._Date).getTime(),n.specStart(e._id,e.title)}),e.on("fail",function(t,n){"hook"===t.type||t._finished?(t._hook="hook"===t.type&&t.title||!0,t._failures=[n],e.emit("test end",t)):t._failures.push(n)}),e.on("test end",function(e){e._finished=!0;var t=n.specEnd(),i=e.pending===!0,r={id:e._id,timeRange:t,name:e.title,suite:s.slice(1),success:"passed"===e.state,skipped:i,time:i?0:(new n._Date).getTime()-e._time,log:[],hook:e._hook,slow:e.slow?e.duration>e.slow():void 0,testFile:e._testFile};if(!r.success&&!r.skipped)for(var a=e._failures,o=0;o<a.length;o++){var l=a[o],c=l.uncaught&&l.message,u={message:c?l.message.substr(0,l.message.lastIndexOf(" (")):l.message,stack:l.stack||c&&l.message.substring(l.message.lastIndexOf("(")+1,l.message.length-1)};n.setAssertionData(l,u),r.log.push(u)}r.log.length||delete r.log,n.result(r)})}});var r=e.it;e.it=function(){var e=Function.prototype.apply.call(r,this,arguments);return e._testFile=n.entryFile(),e},e.it.only=r.only,e.it.skip=r.skip}(window);