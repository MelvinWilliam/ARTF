/*
 * Wallaby.js - v1.0.444
 * http://wallabyjs.com
 * Copyright (c) 2014-2017 Wallaby.js - All Rights Reserved.
 *
 * This source code file is a part of Wallaby.js and is a proprietary (closed source) software.

 * IMPORTANT:
 * Wallaby.js is a tool made by software developers for software developers with passion and love for what we do.
 * Pirating the tool is not only illegal and just morally wrong,
 * it is also unfair to other fellow programmers who are using it legally,
 * and very harmful for the tool and its future.
 */
!function(e){var t,n=e.$_$tracer,i=n.initialSpecId();QUnit.begin(function(e){n.started({total:e.totalTests})}),QUnit.done(function(){n.complete()}),QUnit.testStart(function(e){var s=QUnit.config;if(n.hasSpecFilter()){var r=[e.name.replace(/\s\s*$/,"")];if(e.module&&r.unshift(e.module),!n.specFilter(r)){for(;s.queue.length;){var a=s.queue.shift();if(a&&~a.toString().indexOf(".finish();"))return}return}}s.current.run=function(){var e;n.needToNotifySingleTestRun()&&s.queue.unshift(function(){n.notifySingleTestAfterEach(function(){s.current&&QUnit.start()}),QUnit.stop()}),s.current=this,delete s.current.stack,this.async&&QUnit.stop(),this.callbackStarted=(new Date).getTime();try{n.specSyncStart(),e=this.callback.call(this.testEnvironment,this.assert),this.resolvePromise(e)}catch(t){this.pushFailure(t.message,t.stack),s.blocking&&s.current&&QUnit.start()}finally{n.specSyncEnd()}},t={success:!0,errors:[],id:++i,start:(new n._Date).getTime()},n.specStart(t.id,e.name)}),QUnit.log(function(e){if(!e.result){var i="",s=e.expected,r=e.actual;e.message&&(i+=e.message),t.success=!1,e.showDiff=!0;var a=n.setAssertionData(e,{message:i,stack:e.source});delete e.showDiff,t.errors.push(a),(!e.message||"undefined"!=typeof e.expected&&a.expected)&&(a.message+=(e.message?"\n":"")+"Expected: "+n._inspect(s,3)+"\nActual: "+n._inspect(r,3))}}),QUnit.testDone(function(e){var i=n.specEnd(),s={id:t.id,timeRange:i,name:e.name,suite:e.module&&[e.module]||[],success:t.success,skipped:!1,time:(new n._Date).getTime()-t.start,log:t.errors||[]};s.log.length||delete s.log,n.result(s)})}(window);